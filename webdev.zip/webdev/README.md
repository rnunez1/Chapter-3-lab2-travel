# Web Development – Chapter 3 Assignment

**Student:** Ramon
**Course:** Foundations of Web Development – Chapter 3 (CSS)

This repository holds both Chapter 3 labs:

| Lab | Folder | Files |
|-----|--------|-------|
| Lab 3.1 – Practice with the Cascade | `ch3/Ch3Assignment/` | `ch3.css`, `ch3Advantage1.html`, `ch3Advantage2.html` |
| Lab 3.2 – Travel Blog Visual Identity | `ch3/travel-blog/` | `styles.css`, `index.html`, `about.html`, `destinations.html`, `trip-planner.html`, `contact.html` |

## Folder structure

```
webdev/
├── README.md
└── ch3/
    ├── Ch3Assignment/
    │   ├── ch3.css
    │   ├── ch3Advantage1.html
    │   └── ch3Advantage2.html
    └── travel-blog/
        ├── styles.css
        ├── index.html
        ├── about.html
        ├── destinations.html
        ├── trip-planner.html
        └── contact.html
```

---

## Lab 3.1 – Practice with the Cascade

### Step 1 – Create ch3Advantage1.html
1. Inside `webdev/ch3/Ch3Assignment/`, create `ch3Advantage1.html`.
2. Put the heading "CSS Advantages" inside `<h1>` tags.
3. Add an unordered list (`<ul>`) with three advantages of CSS.
4. Give one list item `class="news"`.
5. Add a hyperlink to `https://www.w3.org` and an email (`mailto:`) link to yourself.
6. In the `<head>`, link the style sheet: `<link rel="stylesheet" href="ch3.css">`.

### Step 2 – Create ch3.css (first version)
Create `ch3.css` in the same folder with these rules:

```css
body {
  background-color: white;
  color: #000099;
  font-family: Arial, Helvetica, sans-serif;
}
a {
  background-color: #CCCCCC;
}
h1 {
  font-family: "Times New Roman", serif;
  color: black;
}
.news {
  color: red;
  font-style: italic;
}
```

### Step 3 – Test in the browser
Open `ch3Advantage1.html` in Chrome/Firefox. You should see a white page, navy text, gray backgrounds behind both links, a black Times New Roman heading, and the "news" item in red italics.

### Step 4 – Change the external style sheet
Edit `ch3.css`:
- `body` background → `black`
- `body` text color → `white`
- `h1` color → `#CCCCCC`

Save, then **reload** `ch3Advantage1.html`. The page picks up the new look automatically without touching the HTML. *(The submitted `ch3.css` is this final version; the original values are left as comments.)*

### Step 5 – Inline style override
1. Copy `ch3Advantage1.html` and save it as `ch3Advantage2.html`.
2. Change the heading to `<h1 style="color: red;">CSS Advantages</h1>`.
3. Open it in the browser. The heading is **red**, not gray. The inline style wins because it is closer to the element than the external style sheet. This is the cascade's order of precedence.

### Step 6 – Organize and submit
Keep all three files in `/webdev/ch3/Ch3Assignment/` and push to GitHub (see "Uploading to GitHub" below).

---

## Lab 3.2 – Travel Blog Visual Identity

### Step 1 – CSS custom properties
At the top of `styles.css`, a `:root` block defines the site's variables:
`--primary-color`, `--accent-color`, `--visited-color`, `--bg-color`, `--text-color`, `--heading-font`, and `--body-font`.

### Step 2 – Typographic hierarchy
`body`, `h1`, `h2`, and `p` are all styled with `var()`. Headings use Georgia (serif), body text uses Trebuchet MS (sans-serif), and sizes step down from `h1` (2.4em) to `h2` (1.6em) to `p` (1em).

### Step 3 – Class selector
`.callout` (white box, marigold left border, italic text) is applied to the travel tip paragraph on `index.html`.

### Step 4 – Id selector
`#site-footer` styles the single footer on each page (teal background, white centered text).

### Step 5 – Link pseudo-classes
Every link in the shared `<nav>` has `:link`, `:visited`, and `:hover` styles. Links inside `<main>` have them too. They are written in the correct order: link → visited → hover.

### Step 6 – Link styles.css to all five pages
Each page's `<head>` contains:
```html
<link rel="stylesheet" href="styles.css">
```
on `index.html`, `about.html`, `destinations.html`, `trip-planner.html`, and `contact.html`.

### Step 7 – Validate
1. Go to https://jigsaw.w3.org/css-validator/
2. Choose **By file upload**, select `styles.css`, and click **Check**.
3. Fix any errors it reports, then re-check until it says no errors were found.
4. (Optional) Also check each HTML page at https://validator.w3.org/

---

## Uploading to GitHub

1. Log in at https://github.com.
2. Open your class repository (or click **+ → New repository**, name it, and click **Create repository**).
3. Click **Add file → Upload files**.
4. Drag the whole `webdev` folder (or the `ch3` folder) into the upload box so the folder structure is kept.
5. Add a commit message such as `Chapter 3 labs` and click **Commit changes**.
6. Confirm the files appear under `ch3/Ch3Assignment/` and `ch3/travel-blog/`.
7. **If you use GitHub Pages:** go to **Settings → Pages**, pick the `main` branch, and save. Your pages will be at `https://<your-username>.github.io/<repo-name>/ch3/travel-blog/`.

## Before submitting
- Replace `your-email@example.com` with your real email in `ch3Advantage1.html`, `ch3Advantage2.html`, and `contact.html`.
